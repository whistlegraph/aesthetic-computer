score-analysis-zh — embedded source bundle

Included files
- references.bib (BIB source)
- score-analysis-zh.tex (TEX source)

Purpose
This machine-readable bundle accompanies the rendered PDF for accessibility, audit, quotation, and reproducible editing. The PDF remains the canonical reading edition. The bundle is deliberately limited to text source files; private evidence, credentials, raw datasets, generated PDFs, and unlisted assets are excluded.

relay-rollback — embedded source bundle

Included files
- notes.md (MD source)
- references.bib (BIB source)
- relay-rollback.tex (TEX source)
- source-bundle.json (JSON source)

Purpose
This machine-readable bundle accompanies the rendered PDF for accessibility, audit, quotation, and reproducible editing. The PDF remains the canonical reading edition. The bundle is deliberately limited to text source files; private evidence, credentials, raw datasets, generated PDFs, and unlisted assets are excluded.

harness-factory — embedded source bundle

Included files
- harness-factory.tex (TEX source)
- references.bib (BIB source)

Purpose
This machine-readable bundle accompanies the rendered PDF for accessibility, audit, quotation, and reproducible editing. The PDF remains the canonical reading edition. The bundle is deliberately limited to text source files; private evidence, credentials, raw datasets, generated PDFs, and unlisted assets are excluded.
